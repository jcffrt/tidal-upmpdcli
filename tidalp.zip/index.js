'use strict';

var libQ = require('kew');
var libNet = require('net');
var libFast = require('fast.js');
var fs=require('fs-extra');
var config = new (require('v-conf'))();
var exec = require('child_process').exec;
var nodetools = require('nodetools');

// Define the ControllerTidal class
module.exports = ControllerTidal;
function ControllerTidal(context) {
	// This fixed variable will let us refer to 'this' object at deeper scopes
	var self = this;

	this.context = context;
	this.commandRouter = this.context.coreCommand;
	this.logger = this.context.logger;
	this.configManager = this.context.configManager;

}



ControllerTidal.prototype.onVolumioStart = function()
{
	var self = this;
	var configFile=this.commandRouter.pluginManager.getConfigurationFile(this.context,'config.json');
	this.config = new (require('v-conf'))();
	this.config.loadFile(configFile);

	//if(self.config.get('bitrate')===true)
	//	self.samplerate="320Kbps";
	//else self.samplerate="128Kbps";
	
	return libQ.resolve();
}

ControllerTidal.prototype.getConfigurationFiles = function()
{
	return ['config.json'];
}



// Plugin methods -----------------------------------------------------------------------------



ControllerTidal.prototype.onStop = function() {
	var self = this;

    var defer=libQ.defer();

	//self.logger.info("Killing SpopD daemon");
	//exec("/usr/bin/sudo /usr/bin/killall spopd", function (error, stdout, stderr) {
	//	if(error){
	//		self.logger.info('Cannot kill spop Daemon')
 //           defer.resolve();
	//	} else {
	//		defer.resolve()
	//	}
	//});

    return defer.promise;
};

ControllerTidal.prototype.onStart = function() {
	var self = this;

	var defer=libQ.defer();

	//self.startSpopDaemon()
	//	.then(function(e)
	//	{
	//		setTimeout(function () {
	//			self.logger.info("Connecting to daemon");
	//			self.spopDaemonConnect(defer);
	//		}, 5000);
	//	})
	//	.fail(function(e)
	//	{
	//		defer.reject(new Error());
	//	});
	//this.commandRouter.sharedVars.registerCallback('alsa.outputdevice', this.rebuildSPOPDAndRestartDaemon.bind(this));

	return defer.promise;
};



// Controller functions

// Spop stop
//ControllerTidal.prototype.stop = function() {
//	var self = this;
//	self.commandRouter.pushConsoleMessage('[' + Date.now() + '] ' + 'ControllerTidal::stop');

//	return self.sendSpopCommand('stop', []);
//};

ControllerTidal.prototype.onRestart = function() {
	var self = this;
	//
};

ControllerTidal.prototype.onInstall = function() {
	var self = this;
	//Perform your installation tasks here
};

ControllerTidal.prototype.onUninstall = function() {
	var self = this;
	//Perform your installation tasks here
};

ControllerTidal.prototype.getUIConfig = function() {
	var defer = libQ.defer();
	var self = this;

	var lang_code = this.commandRouter.sharedVars.get('language_code');

	self.commandRouter.i18nJson(__dirname+'/i18n/strings_'+lang_code+'.json',
		__dirname+'/i18n/strings_en.json',
		__dirname + '/UIConfig.json')
		.then(function(uiconf)
		{

			uiconf.sections[0].content[0].value = self.config.get('username');
			uiconf.sections[0].content[1].value = self.config.get('password');
			uiconf.sections[0].content[2].value = self.config.get('bitrate');

			defer.resolve(uiconf);
		})
		.fail(function()
		{
			defer.reject(new Error());
		});

	return defer.promise;
};

ControllerTidal.prototype.setUIConfig = function(data) {
	var self = this;
	//Perform your installation tasks here
};

ControllerTidal.prototype.getConf = function(varName) {
	var self = this;
	//Perform your installation tasks here
};

ControllerTidal.prototype.setConf = function(varName, varValue) {
	var self = this;
	//Perform your installation tasks here
};

// Public Methods ---------------------------------------------------------------------------------------
// These are 'this' aware, and return a promise


ControllerTidal.prototype.logDone = function(timeStart) {
	var self = this;
	self.commandRouter.pushConsoleMessage('[' + Date.now() + '] ' + '------------------------------ ' + (Date.now() - timeStart) + 'ms');
	return libQ.resolve();
};

ControllerTidal.prototype.logStart = function(sCommand) {
	var self = this;
	self.commandRouter.pushConsoleMessage('\n' + '[' + Date.now() + '] ' + '---------------------------- ' + sCommand);
	return libQ.resolve();
};



ControllerTidal.prototype.pushTidalConfUpmpdcli = function (data) {
	var self = this;

    var defer = libQ.defer();
    var upnpPlugin = self.commandRouter.pluginManager.getPlugin('audio_interface', 'upnp');
    var upmpdcliconftmpl0 = "/volumio/app/plugins/audio_interface/upnp/upmpdcli.conf.tmpl0";
    var upmpdcliconftmpl = "/volumio/app/plugins/audio_interface/upnp/upmpdcli.conf.tmpl";

	try {
        fs.readFile(upmpdcliconftmpl0, 'utf8', function (err, data) {
//		fs.readFile(__dirname + "/spop.conf.tmpl", 'utf8', function (err, data) {
			if (err) {
				defer.reject(new Error(err));
				return console.log(err);
            }

			//var outdev = self.commandRouter.sharedVars.get('alsa.outputdevice');
   //         var hwdev = 'hw:' + outdev;
			//if (outdev === 'softvolume') {
   //             hwdev = 'softvolume';
			//}
			//var  bitrate = self.config.get('bitrate');
			//var bitratevalue = 'true';
			//if (bitrate == false ) {
			//	bitratevalue = 'false';
			//}

			//var conf1 = data.replace("${username}", self.config.get('username'));
			//var conf2 = conf1.replace("${password}", self.config.get('password'));
			//var conf3 = conf2.replace("${bitrate}", self.config.get('bitrate'));
			//var conf4 = conf3.replace("${outdev}", hwdev);

            var tidalUser = data['username'];
            var tidalPass = data['password'];
            var tidalQual = data['bitrate'];
            //Adds the real credentials and quality chosen by user and writes it to template
            var conf1 = content.replace('{TIDAL-USER}', tidalUser);
            conf2 = conf1.replace('{TIDAL-PASS}', tidalPass);
            conf3 = conf1.replace('{TIDAL-QUAL}', tidalQual);
            fs.writeFile(upmpdcliconftmpl, conf3, 'utf8', function (err) {
//			fs.writeFile("/etc/spopd.conf", conf4, 'utf8', function (err) {
				if (err)
					defer.reject(new Error(err));
                else
                    //Restarts upmpdcli to take new data
                    upnpPlugin.onRestart();
                    defer.resolve();
			});


		});


	}
	catch (err) {


	}

	return defer.promise;

};


//tidalupnp.prototype.pushTidalConfUpmpdcli = function (data) {
//    var self = this;
//    var upnpPlugin = self.commandRouter.pluginManager.getPlugin('audio_interface', 'upnp');

//    setTimeout(function () {

//        var systemController = self.commandRouter.pluginManager.getPlugin('system_controller', 'system');

//        //The plugin installs a upmpdcli config template that has the streaming section params included - .tmpl0
//        //From this, the standard template is replaced with user input Tidal parameters
//        var upmpdcliconftmpl0 = "/volumio/app/plugins/audio_interface/upnp/upmpdcli.conf.tmpl0";
//        var upmpdcliconftmpl = "/volumio/app/plugins/audio_interface/upnp/upmpdcli.conf.tmpl";
//        var tidalUser = data['username'];
//        var tidalPass = data['password'];
//        var tidalQual = data['bitrate'];
//        //Reads template0
//        fs.readFile(upmpdcliconftmpl0, 'utf8', function (err, content) {
//            if (err) {
//                return self.logger.log('Error reading Upnp config file: ' + err);
//            }
//            //Adds the real credentials and quality chosen by user and writes it to template
//            var conf1 = content.replace('{TIDAL-USER}', tidalUser);
//            conf1 = conf1.replace('{TIDAL-PASS}', tidalPass);
//            conf1 = conf1.replace('{TIDAL-QUAL}', tidalQual);
//            fs.writeFile(upmpdcliconftmpl, conf1, 'utf8', function (err) {
//                if (err) {
//                    self.logger.log('Error writing Upnp config file: ' + err);
//                }
//                //Restarts upmpdcli to take new data
//                upnpPlugin.onRestart();
//            });
//        });


//    }, 10000)
//}



ControllerTidal.prototype.saveTidalAccount = function (data) {
	var self = this;

	var defer = libQ.defer();

	self.config.set('username', data['username']);
	self.config.set('password', data['password']);
	self.config.set('bitrate', data['bitrate']);

    self.pushTidalConfUpmpdcli()
		.then(function(e){
			self.commandRouter.pushToastMessage('success', "Configuration update", 'The configuration has been successfully updated');
			defer.resolve({});
		})
		.fail(function(e)
		{
			defer.reject(new Error());
		});

	return defer.promise;
};


//ControllerTidal.prototype.rebuildSPOPDAndRestartDaemon = function () {
//	var self=this;
//	var defer=libQ.defer();

//	self.createSPOPDFile()
//		.then(function(e)
//		{
//			var edefer=libQ.defer();
//			exec("killall spopd", function (error, stdout, stderr) {
//				edefer.resolve();
//			});
//			return edefer.promise;
//		})
//		.then(self.startSpopDaemon.bind(self))
//		.then(function(e)
//		{
//			setTimeout(function () {
//				self.logger.info("Connecting to daemon");
//				self.spopDaemonConnect(defer);
//			}, 5000);
//		});

//	return defer.promise;
//};
